#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#ifdef _WIN32
#include <windows.h>
#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
#endif
#endif

// ======= UTILIDADES =======
void clear_screen() {
    printf("\033[2J\033[1;1H");
    fflush(stdout);
}

void my_usleep(unsigned long usecs) {
    struct timespec ts, rem;
    ts.tv_sec = usecs / 1000000;
    ts.tv_nsec = (usecs % 1000000) * 1000;
    while (nanosleep(&ts, &rem) == -1) {
        if (errno == EINTR) ts = rem;
        else return;
    }
}

// Dibuja un rectángulo blanco (on=1) o negro (on=0) usando ANSI
void draw_rect(int on) {
    int start_row = 5, start_col = 10;
    int height = 10, width = 30;

    const char *bg_color = on ? "\033[47m" : "\033[40m"; // blanco / negro

    for (int i = 0; i < height; i++) {
        printf("\033[%d;%dH", start_row + i, start_col); // mover cursor
        printf("%s", bg_color);
        for (int j = 0; j < width; j++) {
            putchar(' ');
        }
        printf("\033[0m"); // reset
    }
    fflush(stdout);
}

// ======= TOKEN =======
int verify_token() {
    time_t t = time(NULL);
    int base = (int)(t / 30);         // ventana de 30s
    int token_val = base % 1000000;   // 6 dígitos
    char expected[7];
    sprintf(expected, "%06d", token_val);

    char token[16];
    printf("\nIngresa el TOKEN (6 digitos), 'm' para volver al menu o '2' para salir: ");
    if (scanf("%15s", token) != 1) return 0;

    if (strcmp(token, "2") == 0) return 2;  // salir del programa
    if (strcmp(token, "m") == 0 || strcmp(token, "M") == 0) return 1; // volver al menu

    if (strcmp(token, expected) == 0) {
        printf("TOKEN verificado correctamente.\n");
    } else {
        printf("TOKEN invalido. El esperado era: %s\n", expected);
    }

    return 0; // continuar verificando
}

// ======= SINCRONIZACION =======
void flash_byte(int byte) {
    for (int bit = 7; bit >= 0; bit--) {
        int val = (byte >> bit) & 1;
        draw_rect(1);
        my_usleep(val ? 500000 : 1000000);  // 0.5s para '1', 1s para '0'
        draw_rect(0);
        my_usleep(800000);  // pausa corta entre bits
    }
}

void sincronizar_y_verificar() {
    // Pulsos iniciales de sincronizacion
    for (int i = 0; i < 3; i++) {
        draw_rect(1);
        my_usleep(1000000); // 1s encendido
        draw_rect(0);
        my_usleep(500000);  // 0.5s apagado
    }

    // Flash de hora/min/seg
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    flash_byte(tm->tm_hour);
    my_usleep(1000000);
    flash_byte(tm->tm_min);
    my_usleep(1000000);
    flash_byte(tm->tm_sec);
    clear_screen();

    // Ciclo de verificacion
    while (1) {
        int r = verify_token();
        if (r == 1) { // volver al menu
            clear_screen();
            break;
        } else if (r == 2) { // salir
            clear_screen();
            printf("Saliendo...\n");
            exit(0);
        }
        printf("Esperando 30 segundos para el proximo TOKEN...\n");
        my_usleep(30000000);
        clear_screen();
    }
}

// ======= MENU PRINCIPAL =======
void mostrar_menu() {
    printf("\n===== MENU PRINCIPAL =====\n");
    printf("1. Sincronizar y generar/verificar TOKEN\n");
    printf("2. Salir\n");
    printf("Elige una opcion: ");
}

int main() {
#ifdef _WIN32
    // Activar soporte ANSI en la consola de Windows
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    GetConsoleMode(hOut, &dwMode);
    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    SetConsoleMode(hOut, dwMode);
#endif

    int opcion = 0;
    while (1) {
        mostrar_menu();
        if (scanf("%d", &opcion) != 1) {
            while (getchar() != '\n');
            continue;
        }

        switch (opcion) {
            case 1:
                sincronizar_y_verificar();
                break;
            case 2:
                printf("Saliendo...\n");
                return 0;
            default:
                printf("Opcion invalida.\n");
        }
    }
}
